/*===================== MOSTRAR MENÚ =======================*/
const navMenu = document.getElementById('nav-menu'),
        navToggle= document.getElementById('nav-toggle'),
        navClose= document.getElementById('nav-close')
/*===================== MOSTRAR MENÚ =======================*/
if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
        navMenu.classList.add('show-menu');
    });
}
/*===================== OCULTAR MENÚ =======================*/
if(navClose){
    navClose.addEventListener('click', () => {
        navMenu.classList.remove('show-menu')
    })
}
/*===================== ELIMINAR MENÚ MÓVIL =======================*/
const linkAction = () => {
    const navMenu = document.getElementById('nav-menu');
    if (navMenu) {
    navMenu.classList.remove('show-menu');
    }
}
const navLink = document.querySelectorAll('.nav__link');
navLink.forEach(n => n.addEventListener('click', linkAction));

/*===================== CAMBIAR FONDO DEL ENCABEZADO =======================*/
const bgHeader = () => {
    const header = document.getElementById('header');
    this.scrollY >= 50 ? header.classList.add('bg-header')
                        : header.classList.remove('bg-header')      
}
window.addEventListener('scroll', bgHeader)
bgHeader()
/*===================== SWIPER SERVICES =======================*/
const swiperServices = new Swiper('.services__swiper', {
    loop: true,
    grabCursor: true,
    spaceBetween: 24,
    slidesPerView: 'auto',
  
    
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  
    
    })
/*===================== CLIENTES =======================*/
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('clienteForm');
    const tabla = document.querySelector("#tablaClientes tbody");
    let clientes = JSON.parse(localStorage.getItem('clientes')) || [];

    // Calculadora de descuento
    function calcularDescuento(tipo, costo) {
        if (tipo === 'casual') return costo * 0.05; // 5% de descuento
        if (tipo === 'permanente') return costo * 0.10; // 10% de descuento
        return 0; // Cliente nuevo no tiene descuento
    }

    function guardarClientes() {
        localStorage.setItem('clientes', JSON.stringify(clientes));
        renderTabla();
    }

    function renderTabla() {
        tabla.innerHTML = '';
        clientes.forEach((cliente, index) => {
            const fila = document.createElement('tr');
            const descuento = calcularDescuento(cliente.tipoCliente, cliente.costoObra);
            const totalConDescuento = cliente.costoObra - descuento;

            fila.innerHTML = `
                <td data-label="Cédula">${cliente.cedula}</td>
                <td data-label="Nombres">${cliente.nombres}</td>
                <td data-label="Apellidos">${cliente.apellidos}</td>
                <td data-label="Email">${cliente.email}</td>
                <td data-label="Teléfono">${cliente.telefono}</td>
                <td data-label="Sexo">${cliente.sexo}</td>
                <td data-label="Fecha de Nacimiento">${cliente.fechaNacimiento}</td>
                <td data-label="Dirección">${cliente.direccion}</td>
                <td data-label="Departamento">${cliente.departamento}</td>
                <td data-label="Municipio">${cliente.municipio}</td>
                <td data-label="Tipo de Cliente">${cliente.tipoCliente}</td>
                <td data-label="Costo de la Obra">${cliente.costoObra.toFixed(2)}</td>
                <td data-label="Total con Descuento">${totalConDescuento.toFixed(2)}</td>
                <td data-label="Acciones">
                    <button onclick="editarCliente(${index})" >Editar</button>
                    <button onclick="eliminarCliente(${index})">Eliminar</button>
                </td>
            `;
            tabla.appendChild(fila);
        });
    }

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const nuevoCliente = {
            cedula: document.getElementById('cedula').value,
            nombres: document.getElementById('nombres').value,
            apellidos: document.getElementById('apellidos').value,
            email: document.getElementById('email').value,
            telefono: document.getElementById('telefono').value,
            sexo: document.getElementById('sexo').value,
            fechaNacimiento: document.getElementById('fechaNacimiento').value,
            direccion: document.getElementById('direccion').value,
            departamento: document.getElementById('departamento').value,
            municipio: document.getElementById('municipio').value,
            tipoCliente: document.getElementById('tipoCliente').value,
            costoObra: parseFloat(document.getElementById('costoObra').value),
        };
        
        const index =clientes.findIndex(c => c.cedula === nuevoCliente.cedula);
        if (index >= 0) {
            clientes[index] = nuevoCliente; // Actualizar cliente existente
        } else {
            clientes.push(nuevoCliente); // Agregar nuevo cliente
        }
        guardarClientes();
        form.reset();
    });
       window.eliminarCliente = function(index) {
        clientes.splice(index, 1); // Eliminar cliente
        guardarClientes();
    };

    window.editarCliente = function(index) {
        const cliente = clientes[index];
        document.getElementById('cedula').value = cliente.cedula;
        document.getElementById('nombres').value = cliente.nombres;
        document.getElementById('apellidos').value = cliente.apellidos;
        document.getElementById('email').value = cliente.email;
        document.getElementById('telefono').value = cliente.telefono;
        document.getElementById('sexo').value = cliente.sexo;
        document.getElementById('fechaNacimiento').value = cliente.fechaNacimiento;
        document.getElementById('direccion').value = cliente.direccion;
        document.getElementById('departamento').value = cliente.departamento;
        document.getElementById('municipio').value = cliente.municipio;
        document.getElementById('tipoCliente').value = cliente.tipoCliente;
        document.getElementById('costoObra').value = cliente.costoObra;
    };

    renderTabla();
});
/*===================== PQRS =======================*/
document.getElementById('contact-form').addEventListener("submit", function (e) {
    e.preventDefault();

    const nombre = document.getElementById('nombre').value;
    const email = document.getElementById('email').value;
    const mensaje = document.getElementById('mensaje').value;
    const asunto = document.getElementById('asunto').value;

    if (nombre === '' || email === '' || mensaje === '' || asunto === '') {
        alert('Todos los campos son obligatorios');
        return;
    }

    //Aqui podrias guardar los datos en una base de datos o enviarlos a un servidor
    console.log('Nombre:', nombre);
    console.log('Email:', email);
    console.log('Mensaje:', mensaje);
    console.log('Asunto:', asunto);

    //Mostrar mensaje de éxito
    document.getElementById("respuesta").style.display = "block";
    document.getElementById("respuesta").innerHTML = "¡Gracias por contactarnos! Nos pondremos en contacto contigo pronto.";

    //Limpiar los campos del formulario
    this.reset();

    });
 /*===================== SHOW SCROLL UP =======================*/
 document.addEventListener('DOMContentLoaded', () => {
    const scrollUp = document.getElementById('scroll-up');  
    const handleScrollUp = () => {
    if (scrollUp) {
        window.scrollY >= 350
        ? scrollUp.classList.add('show-scroll')
        : scrollUp.classList.remove('show-scroll');
    }

    
};
window.addEventListener('scroll', handleScrollUp);
    handleScrollUp();
});
    
  /*===================== SCROLL SECTIONS ACTIVE LINK =======================*/
const sections = document.querySelectorAll('section[id]')
const scrollActive = () => {
    const scrollDown = window.scrollY

    sections.forEach(current => {
        const sectionHeight = current.offsetHeight,
                sectionTop = current.offsetTop - 58,
                sectionId = current.getAttribute('id'),
                sectionsClass = document.querySelector('.nav__menu a[href*=' + sectionId + ']');

            if(sectionsClass){        
                if(scrollDown > sectionTop && scrollDown <= sectionTop + sectionHeight){
                    sectionsClass.classList.add('active-link');
                }
                else{
                    sectionsClass.classList.remove('active-link');
                }
            }
    });
    
}
window.addEventListener('scroll', scrollActive)


  /* =============== SCROLL REVEAL ANIMATION =============== */
   const sr = ScrollReveal({
    origin: 'top',
    distance: '100px',
    duration: 2500,
    delay: 400, 
    // reset: true, // Animation repeat
  })

  sr.reveal(`.home__content, .services__data, .services__swiper, .footer__container`)
  sr.reveal(`.home__images`, {origin: 'bottom', delay: 1000})
  sr.reveal(`.about__images, .contact__img`, {origin: 'left'})
  sr.reveal(`.about__data, .contact__data`, {origin: 'right'})
  sr.reveal(`.projects__card`, {interval: 100})