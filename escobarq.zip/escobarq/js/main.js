/*===================== MOSTRAR MENÚ =======================*/
const navMenu = document.getElementById('nav-menu'),
        navToggle= document.getElementById('nav-toggle'),
        navClose= document.getElementById('nav-close')
/*===================== MOSTRAR MENÚ =======================*/
if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
        navMenu.classList.add('show-menu');
    });
}
/*===================== OCULTAR MENÚ =======================*/
if(navClose){
    navClose.addEventListener('click', () => {
        navMenu.classList.remove('show-menu')
    })
}
/*===================== ELIMINAR MENÚ MÓVIL =======================*/
const linkAction = () => {
    const navMenu = document.getElementById('nav-menu');
    if (navMenu) {
    navMenu.classList.remove('show-menu');
    }
}
const navLink = document.querySelectorAll('.nav__link');
navLink.forEach(n => n.addEventListener('click', linkAction));

/*===================== CAMBIAR FONDO DEL ENCABEZADO =======================*/
const bgHeader = () => {
    const header = document.getElementById('header');
    this.scrollY >= 50 ? header.classList.add('bg-header')
                        : header.classList.remove('bg-header')      
}
window.addEventListener('scroll', bgHeader)
bgHeader()
/*===================== SWIPER SERVICES =======================*/
const swiperServices = new Swiper('.services__swiper', {
    loop: true,
    grabCursor: true,
    spaceBetween: 24,
    slidesPerView: 'auto',
  
    
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  
    
    })
/*===================== CLIENTES =======================*/
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('clienteForm');
    const tabla = document.querySelector("#tablaClientes tbody");
    let clientes = JSON.parse(localStorage.getItem('clientes')) || [];

    if (!form || !tabla) return; // Si no existen en el DOM, salir

    function calcularDescuento(tipo, costo) {
        if (tipo === 'casual') return costo * 0.05;
        if (tipo === 'permanente') return costo * 0.10;
        return 0;
    }

    function guardarClientes() {
        localStorage.setItem('clientes', JSON.stringify(clientes));
        renderTabla();
    }

    function renderTabla() {
        tabla.innerHTML = '';
        clientes.forEach((cliente, index) => {
            const descuento = calcularDescuento(cliente.tipo_cliente, cliente.costo_obra);
            const totalConDescuento = cliente.costo_obra - descuento;

            const fila = document.createElement('tr');
            fila.innerHTML = `
                <td>${cliente.cedula}</td>
                <td>${cliente.nombre}</td>
                <td>${cliente.apellidos}</td>
                <td>${cliente.email}</td>
                <td>${cliente.telefono}</td>
                <td>${cliente.sexo}</td>
                <td>${cliente.fecha_nacimiento}</td>
                <td>${cliente.direccion}</td>
                <td>${cliente.departamento}</td>
                <td>${cliente.municipio}</td>
                <td>${cliente.tipo_cliente}</td>
                <td>${cliente.costo_obra.toFixed(2)}</td>
                <td>${totalConDescuento.toFixed(2)}</td>
                <td>
                    <button onclick="editarCliente(${index})">Editar</button>
                    <button onclick="eliminarCliente(${index})">Eliminar</button>
                </td>
            `;
            tabla.appendChild(fila);
        });
    }

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        // Validar todos los campos por si alguno está mal conectado
        const getInput = id => {
            const input = document.getElementById(id);
            return input ? input.value : '';
        };

        const nuevoCliente = {
            cedula: getInput('cedula'),
            nombre: getInput('nombre'),
            apellidos: getInput('apellidos'),
            email: getInput('email'),
            telefono: getInput('telefono'),
            sexo: getInput('sexo'),
            fecha_nacimiento: getInput('fecha_nacimiento'),
            direccion: getInput('direccion'),
            departamento: getInput('departamento'),
            municipio: getInput('municipio'),
            tipo_cliente: getInput('tipo_cliente'),
            costo_obra: parseFloat(getInput('costo_obra')) || 0,
        };

        const index = clientes.findIndex(c => c.cedula === nuevoCliente.cedula);
        if (index >= 0) {
            clientes[index] = nuevoCliente;
        } else {
            clientes.push(nuevoCliente);
        }

        guardarClientes();
        form.reset();
    });

    window.eliminarCliente = function(index) {
        clientes.splice(index, 1);
        guardarClientes();
    };

    window.editarCliente = function(index) {
        const cliente = clientes[index];
        document.getElementById('cedula').value = cliente.cedula;
        document.getElementById('nombre').value = cliente.nombre;
        document.getElementById('apellidos').value = cliente.apellidos;
        document.getElementById('email').value = cliente.email;
        document.getElementById('telefono').value = cliente.telefono;
        document.getElementById('sexo').value = cliente.sexo;
        document.getElementById('fecha_nacimiento').value = cliente.fecha_nacimiento;
        document.getElementById('direccion').value = cliente.direccion;
        document.getElementById('departamento').value = cliente.departamento;
        document.getElementById('municipio').value = cliente.municipio;
        document.getElementById('tipo_cliente').value = cliente.tipo_cliente;
        document.getElementById('costo_obra').value = cliente.costo_obra;
    };

    renderTabla();
});

/*===================== PQRS =======================*/
document.getElementById('contact-form').addEventListener("submit", function (e) {
    e.preventDefault();

    const nombre = document.getElementById('nombre').value;
    const email = document.getElementById('email').value;
    const mensaje = document.getElementById('mensaje').value;
    const asunto = document.getElementById('asunto').value;

    if (nombre === '' || email === '' || mensaje === '' || asunto === '') {
        alert('Todos los campos son obligatorios');
        return;
    }

    //Aqui podrias guardar los datos en una base de datos o enviarlos a un servidor
    console.log('Nombre:', nombre);
    console.log('Email:', email);
    console.log('Mensaje:', mensaje);
    console.log('Asunto:', asunto);

    //Mostrar mensaje de éxito
    document.getElementById("respuesta").style.display = "block";
    document.getElementById("respuesta").innerHTML = "¡Gracias por contactarnos! Nos pondremos en contacto contigo pronto.";

    //Limpiar los campos del formulario
    this.reset();

    });
 /*===================== SHOW SCROLL UP =======================*/
 document.addEventListener('DOMContentLoaded', () => {
    const scrollUp = document.getElementById('scroll-up');  
    const handleScrollUp = () => {
    if (scrollUp) {
        window.scrollY >= 350
        ? scrollUp.classList.add('show-scroll')
        : scrollUp.classList.remove('show-scroll');
    }

    
};
window.addEventListener('scroll', handleScrollUp);
    handleScrollUp();
});
    
  /*===================== SCROLL SECTIONS ACTIVE LINK =======================*/
const sections = document.querySelectorAll('section[id]')
const scrollActive = () => {
    const scrollDown = window.scrollY

    sections.forEach(current => {
        const sectionHeight = current.offsetHeight,
                sectionTop = current.offsetTop - 58,
                sectionId = current.getAttribute('id'),
                sectionsClass = document.querySelector('.nav__menu a[href*=' + sectionId + ']');

            if(sectionsClass){        
                if(scrollDown > sectionTop && scrollDown <= sectionTop + sectionHeight){
                    sectionsClass.classList.add('active-link');
                }
                else{
                    sectionsClass.classList.remove('active-link');
                }
            }
    });
    
}
window.addEventListener('scroll', scrollActive)


  /* =============== SCROLL REVEAL ANIMATION =============== */
   const sr = ScrollReveal({
    origin: 'top',
    distance: '100px',
    duration: 2500,
    delay: 400, 
    // reset: true, // Animation repeat
  })

  sr.reveal(`.home__content, .services__data, .services__swiper, .footer__container`)
  sr.reveal(`.home__images`, {origin: 'bottom', delay: 1000})
  sr.reveal(`.about__images, .contact__img`, {origin: 'left'})
  sr.reveal(`.about__data, .contact__data`, {origin: 'right'})
  sr.reveal(`.projects__card`, {interval: 100})