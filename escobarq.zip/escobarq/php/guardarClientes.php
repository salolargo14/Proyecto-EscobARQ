
<?php
echo "<pre>";
print_r($_POST);
echo "</pre>";

include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cedula = $_POST['cedula'];
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];
    $sexo = $_POST['sexo'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $direccion = $_POST['direccion'];
    $departamento = $_POST['departamento'];
    $municipio = $_POST['municipio'];
    $tipo_cliente = $_POST['tipo_cliente'];
    $costo_obra = $_POST['costo_obra'];

    $sql = "INSERT INTO clientes 
        (cedula, nombre, apellidos, email, telefono, sexo, fecha_nacimiento, direccion, departamento, municipio, tipo_cliente, costo_obra)
        VALUES 
        ('$cedula', '$nombre', '$apellidos', '$email', '$telefono', '$sexo', '$fecha_nacimiento', '$direccion', '$departamento', '$municipio', '$tipo_cliente', '$costo_obra')";

    if ($conn->query($sql) === TRUE) {
        echo "Cliente guardado exitosamente.";
    } else {
        echo "Error al guardar el cliente: " . $conn->error;
    }

    $conn->close();
} else {
    echo "Acceso no permitido.";
}
?>
