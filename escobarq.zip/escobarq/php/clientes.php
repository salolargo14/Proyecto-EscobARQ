
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Clientes</title>
    <style type="text/css">
 
 table {
        border: solid 2px #7e7c7c;
        border-collapse: collapse;
    } 

    th, h1{
        background-color: #cc9623ff;
    }

    td,
    th {
        border: solid 1px #7e7c7c;
        padding: 2px;
        text-align: center;
    }

    </style>
</head>
<body>

</body>
</html>

<?php
// Validamos datos del servidor
$user = "root";
$pass = "";
$host ="localhost";
$db = "escobarq";

//Conectamos a la base de datos
$connection = mysqli_cpnnect($host, $user, $pass, $db);

//Hacemos llamado al input de formulario

$cedula = $_POST['cedula'];
$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$email = $_POST['email'];
$telefono = $_POST['telefono'];
$sexo = $_POST['sexo'];
$fecha_nacimiento = $_POST['fecha_nacimiento'];
$direccion = $_POST['direccion'];
$departamento = $_POST['departamento'];
$municipio = $_POST['municipio'];
$tipo_cliente = $_POST['tipo_cliente'];
$costo_obra = $_POST['costo_obra'];

//Verificamos la conexion a base de datos
if (!$connection) {
    echo "No se ha podido conectar con el servidor" .mysql_error();
    }
else {
    echo "<b><h3>Hemos conectado al servidor</h3></b>";
    }
    //Indicamos el nombre de la base de datos
    $datab = "escobarq";
    //Indicamos seleccionar la base de datos
    $db = mysqli_select_db($connection, $datab);
    if (!$db) 
        {
echo "No se ha podido encontrar la tabla"; 
} 
    else 
        {
        echo "<h3>Tabla seleccionada</h3>";
        }
    //Insertamos datos de registro
    $instruccion_SQL = "INSERT INTO clientes (cedula, nombre, apellidos, email, telefono, sexo, fecha_nacimiento, direccion, departamento, municipio, tipo_cliente, costo_obra)
    VALUES ('$cedula', '$nombre', '$apellidos', '$email', '$telefono', '$sexo', '$fecha_nacimiento', '$direccion', '$departamento', '$municipio', '$tipo_cliente', '$costo_obra')";

    $resultado = mysqli_query($connection, $instruccion_SQL);

    //Consulta = "SELECT * FROM clientes"; si queremos que nos muestre un registro especifico
    $consulta = "SELECT * FROM clientes";

$result = mysqli_query($connection, $consulta);
if (!$result) {
    echo "No se ha podido realizar la consulta";
} else {
    echo "<table>";
    echo "<tr>";
    echo "<th>cedula</th>";
    echo "<th>nombre</th>";
    echo "<th>apellidos</th>";
    echo "<th>email</th>";
    echo "<th>telefono</th>";
    echo "<th>sexo</th>";
    echo "<th>fecha_nacimiento</th>";
    echo "<th>direccion</th>";
    echo "<th>departamento</th>";
    echo "<th>municipio</th>";
    echo "<th>tipo_cliente</th>";
    echo "<th>costo_obra</th>";
    echo "</tr>";
    while ($colum = mysqli_fetch_array($result)) 
    {
        echo "<tr>";
        echo "<td>" . $colum['cedula'] . "</td>";
        echo "<td>" . $colum['nombre'] . "</td>";
        echo "<td>" . $colum['apellidos'] . "</td>";
        echo "<td>" . $colum['email'] . "</td>";
        echo "<td>" . $colum['telefono'] . "</td>";
        echo "<td>" . $colum['sexo'] . "</td>";
        echo "<td>" . $colum['fecha_nacimiento'] . "</td>";
        echo "<td>" . $colum['direccion'] . "</td>";
        echo "<td>" . $colum['departamento'] . "</td>";
        echo "<td>" . $colum['municipio'] . "</td>";
        echo "<td>" . $colum['tipo_cliente'] . "</td>";
        echo "<td>" . $colum['costo_obra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    }

    mysqli_close($connection);

    // Redirigir a la página de clientes después de guardar
    echo'<a href="clientes.php">Volver a Clientes</a>';
?>
