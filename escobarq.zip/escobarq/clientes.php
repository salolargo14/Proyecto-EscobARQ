
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Clientes</title>
</head>
<body>
<section id="clientes">
    <h2>Gestión de clientes</h2>
    
    <form action="php/guardarClientes.php" method="POST" id="clienteForm">
        <input type="text" name="cedula" id="cedula" placeholder="Cédula del cliente" required>
        <input type="text" name="nombre" id="nombre" placeholder="Nombres del cliente" required>
        <input type="text" name="apellidos" id="apellidos" placeholder="Apellidos del cliente" required>
        <input type="email" name="email" id="email" placeholder="Correo electrónico" required>
        <input type="text" name="telefono" id="telefono" placeholder="Teléfono" required>

        <select name="sexo" id="sexo" required>
            <option value="">Seleccione el sexo</option>
            <option value="Masculino">Masculino</option>
            <option value="Femenino">Femenino</option>
            <option value="Otro">Otro</option>
        </select>

        <input type="date" name="fecha_nacimiento" id="fecha_nacimiento" required>
        <input type="text" name="direccion" id="direccion" placeholder="Dirección" required>
        <input type="text" name="departamento" id="departamento" placeholder="Departamento" required>
        <input type="text" name="municipio" id="municipio" placeholder="Municipio" required>

        <label for="tipo_cliente">Tipo de cliente</label>
        <select name="tipo_cliente" id="tipo_cliente" required>
            <option value="">Seleccione el tipo de cliente</option>
            <option value="nuevo">Nuevo</option>
            <option value="casual">Casual</option>
            <option value="permanente">Permanente</option>
        </select>

        <label for="costo_obra">Costo de la obra ($)</label>
        <input type="number" name="costo_obra" id="costo_obra" required min="0" step="0.01">

        <button type="submit">Guardar</button>
    </form> 

    <div id="respuesta" style="display: none; color: green; margin-top: 10px;">
        <p>Cliente guardado correctamente.</p> 
    </div>
</section>
</body>
</html>
